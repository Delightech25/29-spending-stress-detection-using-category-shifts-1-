# README.md
# Web Application Attack Surface Drift Detection System

A security monitoring tool that detects changes (drift) in web application attack surfaces over time.

## Features

- 🔐 **Authentication System**: Secure login with session management
- 📊 **Interactive Dashboard**: Real-time overview of all monitored targets
- 🎯 **Target Management**: Add and monitor multiple web applications
- 🔍 **Attack Surface Scanning**: Automatic discovery of endpoints, parameters, technologies, and APIs
- 📈 **Drift Detection**: Compare scans against baselines to identify changes
- 🚨 **Alert System**: Severity-based alerts for detected changes
- 📋 **Scan History**: Track all scans with timestamps

## Installation

1. Extract the zip file
2. Install dependencies:
   ```bash
   pip install -r requirements.txt