from flask import Flask, render_template, redirect, url_for, request, flash, jsonify, session
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import json
import os
import hashlib
import time
import random
from datetime import datetime, timedelta
import plotly
import plotly.graph_objs as go
import plotly.utils
import pandas as pd
import numpy as np

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-change-this-in-production'
app.config['SESSION_TYPE'] = 'filesystem'

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Mock user database (instead of SQL)
users = {
    'admin': {
        'password': generate_password_hash('admin123'),
        'id': 1,
        'role': 'admin'
    },
    'analyst': {
        'password': generate_password_hash('analyst123'),
        'id': 2,
        'role': 'analyst'
    }
}

# Mock attack surface data storage
ATTACK_SURFACE_FILE = 'data/attack_surface_history.json'
INITIAL_DATA_FILE = 'data/initial_attack_surface.json'

# User class for Flask-Login
class User(UserMixin):
    def __init__(self, user_id, username, role):
        self.id = user_id
        self.username = username
        self.role = role

@login_manager.user_loader
def load_user(user_id):
    for username, user_data in users.items():
        if user_data['id'] == int(user_id):
            return User(user_data['id'], username, user_data['role'])
    return None

# Ensure data directory exists
os.makedirs('data', exist_ok=True)

# Initialize attack surface data if not exists
def initialize_attack_surface_data():
    if not os.path.exists(ATTACK_SURFACE_FILE):
        initial_data = {
            'baseline': {
                'timestamp': datetime.now().isoformat(),
                'endpoints': [
                    {'path': '/api/users', 'method': 'GET', 'parameters': ['id'], 'auth_required': True, 'risk_score': 3},
                    {'path': '/api/products', 'method': 'GET', 'parameters': ['category', 'page'], 'auth_required': False, 'risk_score': 2},
                    {'path': '/api/orders', 'method': 'POST', 'parameters': ['user_id', 'items'], 'auth_required': True, 'risk_score': 4},
                    {'path': '/admin', 'method': 'GET', 'parameters': [], 'auth_required': True, 'risk_score': 5},
                    {'path': '/login', 'method': 'POST', 'parameters': ['username', 'password'], 'auth_required': False, 'risk_score': 3},
                    {'path': '/search', 'method': 'GET', 'parameters': ['q'], 'auth_required': False, 'risk_score': 2}
                ],
                'headers': [
                    {'name': 'X-Frame-Options', 'present': True, 'value': 'DENY'},
                    {'name': 'X-XSS-Protection', 'present': True, 'value': '1; mode=block'},
                    {'name': 'Content-Security-Policy', 'present': False, 'value': None}
                ],
                'technologies': [
                    {'name': 'Flask', 'version': '2.3.3', 'known_vulnerabilities': 2},
                    {'name': 'Jinja2', 'version': '3.1.2', 'known_vulnerabilities': 1}
                ]
            },
            'scans': []
        }
        
        with open(ATTACK_SURFACE_FILE, 'w') as f:
            json.dump(initial_data, f, indent=2)

initialize_attack_surface_data()

# Helper function to load attack surface data
def load_attack_surface_data():
    with open(ATTACK_SURFACE_FILE, 'r') as f:
        return json.load(f)

# Helper function to save attack surface data
def save_attack_surface_data(data):
    with open(ATTACK_SURFACE_FILE, 'w') as f:
        json.dump(data, f, indent=2)

# Generate simulated scan results
def generate_scan_results():
    base_data = load_attack_surface_data()
    baseline = base_data['baseline']
    
    # Simulate drift by randomly adding, removing, or modifying endpoints
    new_endpoints = baseline['endpoints'].copy()
    
    # Random modifications
    if random.random() > 0.3:  # 70% chance of changes
        # Add a new endpoint
        if random.random() > 0.5:
            new_endpoints.append({
                'path': f'/api/new_{random.randint(1, 100)}',
                'method': random.choice(['GET', 'POST', 'PUT', 'DELETE']),
                'parameters': ['data'] if random.random() > 0.5 else [],
                'auth_required': random.choice([True, False]),
                'risk_score': random.randint(1, 5)
            })
        
        # Remove an endpoint
        if random.random() > 0.7 and len(new_endpoints) > 3:
            new_endpoints.pop(random.randint(0, len(new_endpoints)-1))
        
        # Modify an endpoint
        if random.random() > 0.6 and len(new_endpoints) > 0:
            idx = random.randint(0, len(new_endpoints)-1)
            new_endpoints[idx]['auth_required'] = not new_endpoints[idx]['auth_required']
            new_endpoints[idx]['risk_score'] = min(5, new_endpoints[idx]['risk_score'] + random.randint(-1, 1))
    
    # Generate new headers
    new_headers = [
        {'name': 'X-Frame-Options', 'present': random.choice([True, False]), 'value': 'DENY' if random.random() > 0.3 else None},
        {'name': 'X-XSS-Protection', 'present': random.choice([True, False]), 'value': '1; mode=block' if random.random() > 0.3 else None},
        {'name': 'Content-Security-Policy', 'present': random.choice([True, False]), 'value': "default-src 'self'" if random.random() > 0.5 else None}
    ]
    
    # Calculate drift metrics
    drift_analysis = {
        'timestamp': datetime.now().isoformat(),
        'endpoints': new_endpoints,
        'headers': new_headers,
        'technologies': baseline['technologies'],
        'metrics': {
            'total_endpoints': len(new_endpoints),
            'auth_required_count': sum(1 for e in new_endpoints if e['auth_required']),
            'high_risk_count': sum(1 for e in new_endpoints if e['risk_score'] >= 4),
            'header_changes': sum(1 for h1, h2 in zip(baseline['headers'], new_headers) if h1['present'] != h2['present']),
            'drift_score': random.uniform(0.1, 0.8)  # Simulated drift score
        }
    }
    
    return drift_analysis

# Routes
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username in users and check_password_hash(users[username]['password'], password):
            user = User(users[username]['id'], username, users[username]['role'])
            login_user(user)
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html', username=current_user.username)

@app.route('/api/attack-surface/current')
@login_required
def get_current_attack_surface():
    data = load_attack_surface_data()
    return jsonify(data['baseline'])

@app.route('/api/attack-surface/scan-history')
@login_required
def get_scan_history():
    data = load_attack_surface_data()
    return jsonify(data.get('scans', []))

@app.route('/api/attack-surface/perform-scan', methods=['POST'])
@login_required
def perform_scan():
    try:
        # Generate new scan results
        new_scan = generate_scan_results()
        
        # Load existing data
        data = load_attack_surface_data()
        
        # Add to scans history
        if 'scans' not in data:
            data['scans'] = []
        
        data['scans'].append(new_scan)
        
        # Keep only last 10 scans
        if len(data['scans']) > 10:
            data['scans'] = data['scans'][-10:]
        
        # Update baseline to new scan (simulating baseline update)
        data['baseline'] = new_scan
        
        # Save updated data
        save_attack_surface_data(data)
        
        return jsonify({
            'success': True,
            'scan': new_scan,
            'message': 'Scan completed successfully'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/api/attack-surface/drift-metrics')
@login_required
def get_drift_metrics():
    data = load_attack_surface_data()
    scans = data.get('scans', [])
    
    if not scans:
        return jsonify({
            'drift_trend': [],
            'risk_trend': [],
            'summary': {
                'total_scans': 0,
                'avg_drift_score': 0,
                'total_changes': 0
            }
        })
    
    # Prepare drift trend data
    drift_trend = []
    risk_trend = []
    
    for i, scan in enumerate(scans):
        drift_trend.append({
            'scan_number': i + 1,
            'drift_score': scan['metrics']['drift_score'],
            'timestamp': scan['timestamp']
        })
        
        risk_trend.append({
            'scan_number': i + 1,
            'high_risk_count': scan['metrics']['high_risk_count'],
            'auth_required': scan['metrics']['auth_required_count']
        })
    
    # Calculate summary statistics
    summary = {
        'total_scans': len(scans),
        'avg_drift_score': sum(s['metrics']['drift_score'] for s in scans) / len(scans),
        'total_changes': sum(s['metrics']['header_changes'] for s in scans)
    }
    
    return jsonify({
        'drift_trend': drift_trend,
        'risk_trend': risk_trend,
        'summary': summary
    })

@app.route('/api/attack-surface/compare')
@login_required
def compare_scans():
    scan1_idx = request.args.get('scan1', -1, type=int)
    scan2_idx = request.args.get('scan2', -1, type=int)
    
    data = load_attack_surface_data()
    scans = data.get('scans', [])
    
    if len(scans) < 2:
        return jsonify({'error': 'Not enough scans for comparison'}), 400
    
    # Default to last two scans
    if scan1_idx == -1:
        scan1 = scans[-2]
    else:
        scan1 = scans[scan1_idx]
    
    if scan2_idx == -1:
        scan2 = scans[-1]
    else:
        scan2 = scans[scan2_idx]
    
    # Compare endpoints
    endpoints1 = {e['path']: e for e in scan1['endpoints']}
    endpoints2 = {e['path']: e for e in scan2['endpoints']}
    
    added = [e for path, e in endpoints2.items() if path not in endpoints1]
    removed = [e for path, e in endpoints1.items() if path not in endpoints2]
    modified = []
    
    for path, e2 in endpoints2.items():
        if path in endpoints1:
            e1 = endpoints1[path]
            if (e1['method'] != e2['method'] or 
                e1['auth_required'] != e2['auth_required'] or 
                e1['risk_score'] != e2['risk_score']):
                modified.append({
                    'path': path,
                    'changes': {
                        'method': {'old': e1['method'], 'new': e2['method']},
                        'auth_required': {'old': e1['auth_required'], 'new': e2['auth_required']},
                        'risk_score': {'old': e1['risk_score'], 'new': e2['risk_score']}
                    }
                })
    
    # Compare headers
    headers1 = {h['name']: h for h in scan1['headers']}
    headers2 = {h['name']: h for h in scan2['headers']}
    
    header_changes = []
    for name, h2 in headers2.items():
        if name in headers1:
            h1 = headers1[name]
            if h1['present'] != h2['present']:
                header_changes.append({
                    'name': name,
                    'was_present': h1['present'],
                    'is_present': h2['present']
                })
    
    return jsonify({
        'scan1_timestamp': scan1['timestamp'],
        'scan2_timestamp': scan2['timestamp'],
        'added_endpoints': added,
        'removed_endpoints': removed,
        'modified_endpoints': modified,
        'header_changes': header_changes,
        'metrics_change': {
            'drift_score': scan2['metrics']['drift_score'] - scan1['metrics']['drift_score'],
            'total_endpoints': scan2['metrics']['total_endpoints'] - scan1['metrics']['total_endpoints'],
            'high_risk': scan2['metrics']['high_risk_count'] - scan1['metrics']['high_risk_count']
        }
    })

@app.route('/api/attack-surface/charts')
@login_required
def get_charts():
    data = load_attack_surface_data()
    scans = data.get('scans', [])
    
    if not scans:
        return jsonify({'error': 'No scan data available'}), 404
    
    # Create drift score chart
    drift_fig = go.Figure()
    drift_fig.add_trace(go.Scatter(
        x=[s['timestamp'] for s in scans],
        y=[s['metrics']['drift_score'] for s in scans],
        mode='lines+markers',
        name='Drift Score',
        line=dict(color='red', width=2)
    ))
    drift_fig.update_layout(
        title='Attack Surface Drift Over Time',
        xaxis_title='Scan Time',
        yaxis_title='Drift Score',
        hovermode='x'
    )
    
    # Create risk distribution chart
    risk_fig = go.Figure()
    risk_fig.add_trace(go.Bar(
        name='High Risk',
        x=[s['timestamp'] for s in scans],
        y=[s['metrics']['high_risk_count'] for s in scans],
        marker_color='red'
    ))
    risk_fig.add_trace(go.Bar(
        name='Auth Required',
        x=[s['timestamp'] for s in scans],
        y=[s['metrics']['auth_required_count'] for s in scans],
        marker_color='blue'
    ))
    risk_fig.update_layout(
        title='Risk Metrics Over Time',
        xaxis_title='Scan Time',
        yaxis_title='Count',
        barmode='group'
    )
    
    # Convert to JSON
    drift_json = json.dumps(drift_fig, cls=plotly.utils.PlotlyJSONEncoder)
    risk_json = json.dumps(risk_fig, cls=plotly.utils.PlotlyJSONEncoder)
    
    return jsonify({
        'drift_chart': drift_json,
        'risk_chart': risk_json
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)