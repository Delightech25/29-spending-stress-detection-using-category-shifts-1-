#!/usr/bin/env python3
"""Generate sample datasets for testing"""

import json
import random
from datetime import datetime, timedelta

def generate_scan_data(days_ago=0):
    """Generate sample scan data"""
    base_date = datetime.now() - timedelta(days=days_ago)
    
    # Sample endpoints
    endpoints = [
        {"path": "/api/users", "method": "GET", "parameters": ["id"], 
         "auth_required": True, "risk_score": 3},
        {"path": "/api/products", "method": "GET", "parameters": ["category", "page"], 
         "auth_required": False, "risk_score": 2},
        {"path": "/api/orders", "method": "POST", "parameters": ["user_id", "items"], 
         "auth_required": True, "risk_score": 4},
    ]
    
    # Add some random drift
    if random.random() > 0.5:
        endpoints.append({
            "path": f"/api/feature_{random.randint(1,100)}",
            "method": random.choice(['GET', 'POST']),
            "parameters": ["data"],
            "auth_required": random.choice([True, False]),
            "risk_score": random.randint(1,5)
        })
    
    return {
        'timestamp': base_date.isoformat(),
        'endpoints': endpoints,
        'headers': [
            {'name': 'X-Frame-Options', 'present': random.choice([True, False])},
            {'name': 'X-XSS-Protection', 'present': random.choice([True, False])},
        ],
        'technologies': [
            {'name': 'Flask', 'version': '2.3.3', 'known_vulnerabilities': 2}
        ],
        'metrics': {
            'total_endpoints': len(endpoints),
            'auth_required_count': sum(1 for e in endpoints if e['auth_required']),
            'high_risk_count': sum(1 for e in endpoints if e['risk_score'] >= 4),
            'drift_score': random.uniform(0.1, 0.5)
        }
    }

def generate_historical_data(days=30):
    """Generate historical scan data"""
    scans = []
    for i in range(days):
        scans.append(generate_scan_data(i))
    
    return {
        'baseline': generate_scan_data(0),
        'scans': scans
    }

if __name__ == "__main__":
    # Generate and save historical data
    historical = generate_historical_data(30)
    
    with open('data/attack_surface_history.json', 'w') as f:
        json.dump(historical, f, indent=2)
    
    print("✅ Generated sample historical data with 30 days of scans")
    
    # Generate vulnerability database
    vuln_db = {
        'vulnerabilities': [
            {
                'id': f'CVE-2024-{i:04d}',
                'name': f'Sample Vulnerability {i}',
                'severity': random.choice(['low', 'medium', 'high', 'critical']),
                'cvss_score': round(random.uniform(4.0, 10.0), 1)
            }
            for i in range(1, 21)
        ]
    }
    
    with open('data/vulnerability_db.json', 'w') as f:
        json.dump(vuln_db, f, indent=2)
    
    print("✅ Generated sample vulnerability database with 20 entries")