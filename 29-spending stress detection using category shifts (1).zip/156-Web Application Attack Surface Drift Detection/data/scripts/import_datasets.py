#!/usr/bin/env python3
"""Script to import and manage datasets"""

import json
import os
import sys
from datetime import datetime

def import_scan_data(filepath):
    """Import custom scan data"""
    try:
        with open(filepath, 'r') as f:
            scan_data = json.load(f)
        
        # Load existing history
        history_file = 'data/attack_surface_history.json'
        if os.path.exists(history_file):
            with open(history_file, 'r') as f:
                history = json.load(f)
        else:
            history = {'baseline': {}, 'scans': []}
        
        # Add timestamp if not present
        if 'timestamp' not in scan_data:
            scan_data['timestamp'] = datetime.now().isoformat()
        
        # Add to history
        history['scans'].append(scan_data)
        
        # Save
        with open(history_file, 'w') as f:
            json.dump(history, f, indent=2)
        
        print(f"✅ Imported scan data from {filepath}")
        return True
    
    except Exception as e:
        print(f"❌ Error importing {filepath}: {e}")
        return False

def update_vulnerability_db(new_vulns):
    """Update vulnerability database"""
    db_file = 'data/vulnerability_db.json'
    
    if os.path.exists(db_file):
        with open(db_file, 'r') as f:
            db = json.load(f)
    else:
        db = {'vulnerabilities': [], 'weaknesses': []}
    
    # Add new vulnerabilities
    db['vulnerabilities'].extend(new_vulns)
    
    # Save
    with open(db_file, 'w') as f:
        json.dump(db, f, indent=2)
    
    print(f"✅ Added {len(new_vulns)} vulnerabilities to database")

def export_compliance_report():
    """Export compliance report to file"""
    # This would call your compliance checking logic
    pass

if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "import-scan":
            import_scan_data(sys.argv[2])
        elif sys.argv[1] == "update-vulns":
            with open(sys.argv[2], 'r') as f:
                new_vulns = json.load(f)
            update_vulnerability_db(new_vulns)
    else:
        print("Usage: python import_datasets.py <command> <file>")
        print("Commands: import-scan, update-vulns")