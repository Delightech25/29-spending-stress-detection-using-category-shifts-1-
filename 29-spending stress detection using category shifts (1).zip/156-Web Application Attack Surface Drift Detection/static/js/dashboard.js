// Dashboard JavaScript

let chartsInitialized = false;

// Load initial data when page loads
document.addEventListener('DOMContentLoaded', function() {
    loadCurrentAttackSurface();
    loadScanHistory();
    loadCharts();
    loadDriftMetrics();
    
    // Auto-refresh every 30 seconds
    setInterval(refreshData, 30000);
});

// Load current attack surface data
function loadCurrentAttackSurface() {
    fetch('/api/attack-surface/current')
        .then(response => response.json())
        .then(data => {
            updateStats(data);
            updateEndpointsTable(data.endpoints);
            updateHeadersGrid(data.headers);
        })
        .catch(error => {
            console.error('Error loading attack surface:', error);
            showNotification('Error loading attack surface data', 'error');
        });
}

// Load scan history
function loadScanHistory() {
    fetch('/api/attack-surface/scan-history')
        .then(response => response.json())
        .then(data => {
            updateHistoryTable(data);
        })
        .catch(error => {
            console.error('Error loading scan history:', error);
        });
}

// Load charts
function loadCharts() {
    fetch('/api/attack-surface/charts')
        .then(response => response.json())
        .then(data => {
            if (data.drift_chart) {
                Plotly.newPlot('drift-chart', JSON.parse(data.drift_chart).data, 
                              JSON.parse(data.drift_chart).layout);
            }
            if (data.risk_chart) {
                Plotly.newPlot('risk-chart', JSON.parse(data.risk_chart).data, 
                              JSON.parse(data.risk_chart).layout);
            }
            chartsInitialized = true;
        })
        .catch(error => {
            console.error('Error loading charts:', error);
        });
}

// Load drift metrics
function loadDriftMetrics() {
    fetch('/api/attack-surface/drift-metrics')
        .then(response => response.json())
        .then(data => {
            updateMetricsSummary(data.summary);
        })
        .catch(error => {
            console.error('Error loading drift metrics:', error);
        });
}

// Update statistics cards
function updateStats(data) {
    document.getElementById('total-endpoints').textContent = data.endpoints.length;
    document.getElementById('auth-endpoints').textContent = 
        data.endpoints.filter(e => e.auth_required).length;
    document.getElementById('high-risk').textContent = 
        data.endpoints.filter(e => e.risk_score >= 4).length;
    
    // Calculate average risk score as drift indicator
    const avgRisk = data.endpoints.reduce((sum, e) => sum + e.risk_score, 0) / data.endpoints.length;
    document.getElementById('drift-score').textContent = avgRisk.toFixed(2);
}

// Update endpoints table
function updateEndpointsTable(endpoints) {
    const tbody = document.getElementById('endpoints-body');
    
    if (!endpoints || endpoints.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center">No endpoints found</td></tr>';
        return;
    }
    
    let html = '';
    endpoints.sort((a, b) => b.risk_score - a.risk_score);
    
    endpoints.forEach(endpoint => {
        const riskClass = endpoint.risk_score >= 4 ? 'risk-high' : 
                         endpoint.risk_score >= 3 ? 'risk-medium' : 'risk-low';
        
        html += `
            <tr>
                <td><code>${escapeHtml(endpoint.path)}</code></td>
                <td><span class="badge">${escapeHtml(endpoint.method)}</span></td>
                <td>${endpoint.parameters ? endpoint.parameters.join(', ') : '-'}</td>
                <td>
                    <span class="status-badge ${endpoint.auth_required ? 'status-secure' : 'status-warning'}">
                        ${endpoint.auth_required ? '🔒 Required' : '🔓 Open'}
                    </span>
                </td>
                <td><span class="risk-badge ${riskClass}">${endpoint.risk_score}/5</span></td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

// Update headers grid
function updateHeadersGrid(headers) {
    const container = document.getElementById('headers-container');
    
    if (!headers || headers.length === 0) {
        container.innerHTML = '<p class="text-center">No header data available</p>';
        return;
    }
    
    let html = '';
    headers.forEach(header => {
        const statusClass = header.present ? 'present' : 'missing';
        const statusText = header.present ? '✅ Present' : '❌ Missing';
        const valueText = header.value ? `Value: ${escapeHtml(header.value)}` : 'Not configured';
        
        html += `
            <div class="header-item ${statusClass}">
                <div class="header-name">${escapeHtml(header.name)}</div>
                <div class="header-status">${statusText}</div>
                <div class="header-value">${valueText}</div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// Update history table
function updateHistoryTable(scans) {
    const tbody = document.getElementById('history-body');
    
    if (!scans || scans.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center">No scan history available</td></tr>';
        return;
    }
    
    let html = '';
    scans.reverse().forEach((scan, index) => {
        const timestamp = new Date(scan.timestamp).toLocaleString();
        const driftClass = scan.metrics.drift_score > 0.5 ? 'risk-high' : 
                          scan.metrics.drift_score > 0.3 ? 'risk-medium' : 'risk-low';
        
        html += `
            <tr>
                <td>${timestamp}</td>
                <td>${scan.metrics.total_endpoints}</td>
                <td><span class="risk-badge risk-high">${scan.metrics.high_risk_count}</span></td>
                <td>${scan.metrics.header_changes}</td>
                <td><span class="risk-badge ${driftClass}">${scan.metrics.drift_score.toFixed(3)}</span></td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

// Update metrics summary
function updateMetricsSummary(summary) {
    // This could be expanded to show more detailed metrics
    console.log('Metrics summary:', summary);
}

// Perform new scan
function performScan() {
    showLoadingOverlay();
    
    fetch('/api/attack-surface/perform-scan', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        hideLoadingOverlay();
        
        if (data.success) {
            showNotification('Scan completed successfully!', 'success');
            
            // Check for significant drift
            if (data.scan.metrics.drift_score > 0.5) {
                showNotification('⚠️ High drift detected! Review changes immediately.', 'warning');
            }
            
            // Refresh all data
            refreshData();
        } else {
            showNotification('Scan failed: ' + data.message, 'error');
        }
    })
    .catch(error => {
        hideLoadingOverlay();
        console.error('Error performing scan:', error);
        showNotification('Error performing scan', 'error');
    });
}

// Refresh all dashboard data
function refreshData() {
    loadCurrentAttackSurface();
    loadScanHistory();
    loadDriftMetrics();
    
    if (chartsInitialized) {
        loadCharts();
    }
    
    showNotification('Data refreshed', 'info');
}

// Compare scans
function compareScans() {
    fetch('/api/attack-surface/compare')
        .then(response => response.json())
        .then(data => {
            displayComparisonResults(data);
        })
        .catch(error => {
            console.error('Error comparing scans:', error);
            showNotification('Error comparing scans', 'error');
        });
}

// Display comparison results in modal
function displayComparisonResults(data) {
    const modal = document.getElementById('comparison-modal');
    const results = document.getElementById('comparison-results');
    
    let html = `
        <div class="comparison-summary">
            <h4>Comparing scans from:</h4>
            <p>Scan 1: ${new Date(data.scan1_timestamp).toLocaleString()}</p>
            <p>Scan 2: ${new Date(data.scan2_timestamp).toLocaleString()}</p>
            
            <div class="metrics-change">
                <h4>Metrics Change</h4>
                <ul>
                    <li>Drift Score: ${data.metrics_change.drift_score.toFixed(3)}</li>
                    <li>Total Endpoints: ${data.metrics_change.total_endpoints}</li>
                    <li>High Risk Endpoints: ${data.metrics_change.high_risk}</li>
                </ul>
            </div>
        </div>
    `;
    
    if (data.added_endpoints.length > 0) {
        html += '<h4>🟢 Added Endpoints</h4><ul>';
        data.added_endpoints.forEach(e => {
            html += `<li class="diff-added">${e.path} (${e.method}) - Risk: ${e.risk_score}</li>`;
        });
        html += '</ul>';
    }
    
    if (data.removed_endpoints.length > 0) {
        html += '<h4>🔴 Removed Endpoints</h4><ul>';
        data.removed_endpoints.forEach(e => {
            html += `<li class="diff-removed">${e.path} (${e.method})</li>`;
        });
        html += '</ul>';
    }
    
    if (data.modified_endpoints.length > 0) {
        html += '<h4>🟡 Modified Endpoints</h4><ul>';
        data.modified_endpoints.forEach(e => {
            html += `<li class="diff-modified">${e.path}`;
            if (e.changes.auth_required) {
                html += `<br>Auth: ${e.changes.auth_required.old} → ${e.changes.auth_required.new}`;
            }
            if (e.changes.risk_score) {
                html += `<br>Risk: ${e.changes.risk_score.old} → ${e.changes.risk_score.new}`;
            }
            html += '</li>';
        });
        html += '</ul>';
    }
    
    if (data.header_changes.length > 0) {
        html += '<h4>Header Changes</h4><ul>';
        data.header_changes.forEach(h => {
            const change = h.was_present ? 'removed' : 'added';
            html += `<li>${h.name}: ${change}</li>`;
        });
        html += '</ul>';
    }
    
    if (data.added_endpoints.length === 0 && data.removed_endpoints.length === 0 && 
        data.modified_endpoints.length === 0 && data.header_changes.length === 0) {
        html += '<p>No significant changes detected between scans.</p>';
    }
    
    results.innerHTML = html;
    modal.style.display = 'block';
}

// Close modal
function closeModal() {
    document.getElementById('comparison-modal').style.display = 'none';
}

// Show loading overlay
function showLoadingOverlay() {
    document.getElementById('loading-overlay').style.display = 'flex';
}

// Hide loading overlay
function hideLoadingOverlay() {
    document.getElementById('loading-overlay').style.display = 'none';
}

// Show notification
function showNotification(message, type) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">×</button>
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

// Utility function to escape HTML
function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('comparison-modal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}