from flask import Flask, render_template, request, redirect, session, url_for
import joblib
import json
import os

app = Flask(__name__)
app.secret_key = "supersecretkey"

# ---------------- LOAD MODEL ----------------
if not os.path.exists("model.pkl"):
    print("Run train_model.py first!")
    exit()

model = joblib.load("model.pkl")
label_encoder = joblib.load("label_encoder.pkl")

# ---------------- USER SYSTEM ----------------
USERS_FILE = "users.json"

if not os.path.exists(USERS_FILE):
    with open(USERS_FILE, "w") as f:
        json.dump({}, f)

def load_users():
    with open(USERS_FILE, "r") as f:
        return json.load(f)

def save_users(users):
    with open(USERS_FILE, "w") as f:
        json.dump(users, f)

# ---------------- ROUTES ----------------

@app.route("/")
def home():
    return redirect(url_for("login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        users = load_users()
        username = request.form["username"]
        password = request.form["password"]

        if username in users:
            return "User already exists!"

        users[username] = {"password": password}
        save_users(users)

        return redirect(url_for("login"))

    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        users = load_users()
        username = request.form["username"]
        password = request.form["password"]

        if username in users and users[username]["password"] == password:
            session["username"] = username
            return redirect(url_for("dashboard"))
        else:
            return render_template("login.html", error="Invalid credentials")

    return render_template("login.html")

@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():
    if "username" not in session:
        return redirect(url_for("login"))

    prediction = None
    probability = None
    advice = None
    chart_data = None

    if request.method == "POST":
        income = float(request.form["income"])
        food = float(request.form["food"])
        shopping = float(request.form["shopping"])
        bills = float(request.form["bills"])
        travel = float(request.form["travel"])
        entertainment = float(request.form["entertainment"])
        savings = float(request.form["savings"])
        debt = float(request.form["debt"])
        emi = float(request.form["emi"])
        unexpected = float(request.form["unexpected"])

        data = [[income, food, shopping, bills, travel,
                 entertainment, savings, debt, emi, unexpected]]

        result = model.predict(data)[0]
        prediction = label_encoder.inverse_transform([result])[0]

        probs = model.predict_proba(data)[0]
        probability = round(max(probs) * 100, 2)

        # Advice logic
        if prediction == "High":
            advice = "⚠️ High Stress: Reduce debt & unnecessary shopping. Increase savings."
        elif prediction == "Medium":
            advice = "⚡ Medium Stress: Try balancing spending and savings better."
        else:
            advice = "✅ Low Stress: Excellent financial management. Keep investing."

        chart_data = [food, shopping, bills, travel,
                      entertainment, savings, debt, emi, unexpected]

    return render_template("dashboard.html",
                           username=session["username"],
                           prediction=prediction,
                           probability=probability,
                           advice=advice,
                           chart_data=chart_data)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

if __name__ == "__main__":
    app.run(debug=True)